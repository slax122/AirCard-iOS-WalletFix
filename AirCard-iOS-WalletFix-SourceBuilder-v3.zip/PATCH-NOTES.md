# Wallet artwork cache fix

The upstream iOS project documents that it writes Wallet artwork and flushes
front-face/thumbnail caches. The public repository currently targets iOS 27+.

This package does not fabricate Rust source that was not present in the uploaded
ZIP. Instead, GitHub Actions retrieves the exact upstream source before any
source-level patch is attempted, so a changed upstream implementation can be
detected instead of silently applying a broken edit.
