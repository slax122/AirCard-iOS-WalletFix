#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
required = [
    root / 'ios-app',
    root / 'rust-core',
    root / 'project.yml',
    root / 'build-ios.sh',
    root / 'build-ipa.sh',
]
missing = [str(p.relative_to(root)) for p in required if not p.exists()]
if missing:
    print('Missing upstream source items:')
    print('\n'.join(missing))
    raise SystemExit(2)

swift = root / 'ios-app' / 'AppViewModel.swift'
rust_candidates = list((root / 'rust-core').rglob('*.rs'))
print('Upstream source tree found.')
print(f'AppViewModel.swift: {swift.exists()}')
print(f'Rust files: {len(rust_candidates)}')

if swift.exists():
    text = swift.read_text(errors='replace')
    for needle in ('FrontFace', 'Preview', 'PlaceHolder'):
        print(f'{needle}: {needle in text}')
